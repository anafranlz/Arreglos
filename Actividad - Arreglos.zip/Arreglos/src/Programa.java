
public class Programa {

	public static void main(String[] args) {

		int[] arrayEnteros = new int[15];
		String[] arrayNombres = new String[20];
		Estudiante[] arrayEstudiantes = new Estudiante[100];
		
		arrayEnteros[10] = 5;
		arrayNombres[0] = "Francisco";
		
		Estudiante uno = new Estudiante(177438, "Ana");
		
	}

}
