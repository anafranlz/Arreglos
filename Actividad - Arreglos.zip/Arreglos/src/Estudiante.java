import java.util.Scanner;

public class Estudiante {

	int ID = 177438;
	String nombre;
	
	public Estudiante(int ID, String nombre)
	{
	        this.ID = ID;
	        this.nombre = nombre;
	}
	
	public int mostrarID()
	{
	        return ID;
	}
	
	public String mostrarNombre()
	{
	        return nombre;
	}
	
	int i, found, indiceFound, nameFound, estudianteFound;
	Scanner scan = new Scanner(System.in);
	String inline, inline2, inline3;
	int enteroBuscado, idBuscado, idFound;
	
	public void mostrarArregloInt(int[] array)
	{
		for(i = 0; i<array.length; i++)
		{
			System.out.println(array[i]);
		}
	}
	
	public void mostrarArregloString(String[] array)
	{
		for(i = 0; i<array.length; i++)
		{
			System.out.println(array[i]);
		}
		return;
	}
	
	public void mostrarArregloEstudiante(Estudiante[] array)
	{
		for(i = 0; i<array.length; i++)
		{
			System.out.println(array[i]);
		}
		return;
	}
	
	public void buscarValor(int[] array)
	{
		found = 0;
		System.out.println("Ingrese el numero a buscar");
		inline = scan.nextLine();
		enteroBuscado = Integer.parseInt(inline);
		for(i = 0; i<array.length; i++)
		{
			if(enteroBuscado == array[i])
			{
				found = 1;
				indiceFound = i;
				break;
			}
		}
		if(found == 1)
		{
			System.out.println("El valor se encontro en el indice: "+i);
		}
		else
		{
			System.out.println("No se encontro el valor");
		}
		return;
	}
	
	public void buscarValor(String[] array)
	{
		nameFound = 0;
		System.out.println("Ingrese el nombre a buscar");
		inline = scan.nextLine();
		for(i = 0; i<array.length; i++)
		{
			if(inline == array[i])
			{
				nameFound = 1;
				indiceFound = i;
				break;
			}
		}
		if(nameFound == 1)
		{
			System.out.println("El nombre se encontro en el indice: "+i);
		}
		else
		{
			System.out.println("No se encontro el nombre");
		}
		return;
	}
	
	public void buscarValor(Estudiante[] array)
	{
		estudianteFound = 0;
		System.out.println("Ingrese el ID del estudiante a buscar (numero entero)");
		inline3 = scan.nextLine();
		idBuscado = Integer.parseInt(inline3);
		idFound = 0;
		
		for(i = 0; i<array.length; i++)
		{
			if (array[i] != null && array[i].mostrarID() == idBuscado)
            {
				idFound = 1;
				System.out.println("El ID del estudiante se encontro en el indice: "+i);
				break;
            }
		}
		if(idFound == 0)
		{
			System.out.println("No se encontro el ID de estudiante");
		}
		return;
	}
	
	public void eliminarValor(int[] array)
	{
		found = 0;
		System.out.println("Ingrese el numero a buscar");
		inline = scan.nextLine();
		enteroBuscado = Integer.parseInt(inline);
		for(i = 0; i<array.length; i++)
		{
			if(enteroBuscado == array[i])
			{
				found = 1;
				indiceFound = i;
				break;
			}
		}
		if (found == 0)
		{
	        System.out.println("No se encontro ese valor en el arreglo, por lo tanto no se puede eliminar");
	    } 
		else 
		{
	        for (int i = indiceFound; i<array.length - 1; i++)
	        {
	            array[i] = array[i + 1];
	        }
	    }
		return;
	}
	
	public void eliminarValor(String[] array)
	{
		found = 0;
		System.out.println("Ingrese el nombre a buscar");
		inline = scan.nextLine();
		for(i = 0; i<array.length; i++)
		{
			if(inline == array[i])
			{
				nameFound = 1;
				indiceFound = i;
				break;
			}
		}
		if (nameFound == 0)
		{
	        System.out.println("No se encontro ese nombre en el arreglo, por lo tanto no se puede eliminar");
	    } 
		else 
		{
	        for (int i = indiceFound; i<array.length - 1; i++)
	        {
	            array[i] = array[i + 1];
	        }
	    }
		return;
	}
	
	public void eliminarValor(Estudiante[] array)
	{
		System.out.println("Ingrese el ID a buscar");
		inline = scan.nextLine();
		idBuscado = Integer.parseInt(inline3);
		idFound = 0;
		
		for(i = 0; i<array.length; i++)
		{
			if (array[i] != null && array[i].mostrarID() == idBuscado)
            {
				idFound = 1;
				indiceFound = i;
				break;
            }
		}
		if (idFound == 0)
		{
	        System.out.println("No se encontro ese ID de estudiante en el arreglo, por lo tanto no se puede eliminar");
	    } 
		else 
		{
	        for (int i = indiceFound; i<array.length - 1; i++)
	        {
	            array[i] = array[i + 1];
	        }
	    }
		return;
    }
}
